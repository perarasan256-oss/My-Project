<?php
// ============================================
// SMS CONFIGURATION
// Fill these values to enable SMS alerts.
// ============================================

return [
    // Supported: fast2sms, custom
    'provider' => 'fast2sms',

    // Required for both providers
    'api_key' => '',

    // Used when provider = custom
    // Example: https://your-sms-provider.example/send
    'api_url' => '',

    // Sender name/id (provider dependent)
    'sender_id' => 'SMARTEXAM',
];

